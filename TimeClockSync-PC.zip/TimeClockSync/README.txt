TimeClock Sync v1.0.0 - PC companion for TimeClock Live  (two-way punch sync with the phone app)
=================================================================================================
Does NOT modify TimeClockLive.ps1. Only the "punches" go to the cloud (private repo vanwidick/timeclock-sync);
profile, PTO, alerts.topic and the sync topic never leave this PC. Needs only built-in Windows PowerShell 5.1, no admin.

1. Create a token (in a browser, signed in as vanwidick):
   https://github.com/settings/personal-access-tokens/new
   - Token name: TimeClock Sync PC      - Expiration: your choice (e.g. 1 year)
   - Repository access: Only select repositories -> vanwidick/timeclock-sync
   - Permissions -> Repository permissions -> Contents: Read and write   (Metadata: Read is added automatically)
   Make a SECOND token the same way for the phone ("TimeClock Sync Phone") so each can be revoked on its own.

2. Unzip this folder anywhere (e.g. Downloads\TimeClockSync), open PowerShell in it and run:
      powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-TimeClockSync.ps1
   Paste the PC token when asked (input hidden). It is stored encrypted with Windows DPAPI in
   %LOCALAPPDATA%\TimeClockSync\token.dat (only your Windows user can decrypt it).
   The installer runs one test sync, then registers the Scheduled Task "TimeClock Sync" (starts hidden at logon,
   syncs every 20 s) and starts it. Log: %LOCALAPPDATA%\TimeClockSync\sync-log.txt

3. Phone: open https://vanwidick.github.io/timeclock-live-lite/ (from the Home Screen icon), scroll to
   "Cloud sync with PC", keep repo vanwidick/timeclock-sync, paste the PHONE token, tap "Connect & sync".

How it behaves
- Desktop punches reach the cloud/phone within ~20 s.
- Phone punches reach the cloud immediately. TimeClock Live only reads timeclock-data.json when it starts, and it
  rewrites the file from memory on every punch, so the companion writes phone punches into the file only while
  TimeClock Live is CLOSED (they wait safely in the cloud until then; the desktop shows them at its next start).
  If TimeClock Live is later updated to reload the file when it changes, reinstall with -FileWrite Always.
- Before writing, the old file is kept as timeclock-data.json.bak; only the "punches" value is replaced.

Uninstall:  powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-TimeClockSync.ps1 -Uninstall
Revoke a token any time at https://github.com/settings/personal-access-tokens
